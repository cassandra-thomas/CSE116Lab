package tests
import org.scalatest._
import clicker.equipment.{Equipment, Excavators, GoldMines, Shovels}
import clicker.Game

class TestUpdate extends FunSuite {
  test("Obj2 has been checked"){
    val shovel1: Shovels = new Shovels(){
      numberOwned = 0
    }
    val excavator1: Excavators = new Excavators(){
      numberOwned = 0
    }
    val mine1: GoldMines = new GoldMines(){
      numberOwned = 0
    }
    val test1: Game = new Game(){
      this.gold = 0.0
      this.lastUpdateTime = System.nanoTime()
      this.equipment = Map("shovel" -> shovel1, "excavator" -> excavator1, "mine" -> mine1)
      buyEquipment("shovel")
      buyEquipment("excavator")
      buyEquipment("mine")
      goldPerSecond()
      clickGold()
    }


    assert(test1.goldPerSecond() == 0.0)
    assert(test1.goldPerClick() == 0.0)
    assert(test1.gold == 0.0)
  }

}
