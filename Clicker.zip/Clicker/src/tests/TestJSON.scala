package tests
import org.scalatest._
import clicker.equipment.{Equipment, Excavators, GoldMines, Shovels}
import clicker.Game

class TestJSON extends FunSuite {
  test("TestJSON has been checked"){

  }

}
