package tests
import org.scalatest._
import clicker.equipment.{Equipment, Excavators, GoldMines, Shovels}
import math.pow

class TestEquipment extends FunSuite {

    val shovel: Shovels = new Shovels() {
      numberOwned = 5
    }
    val shovel1: Shovels = new Shovels() {
      numberOwned = 0
    }
    val goldMine: GoldMines = new GoldMines() {
      numberOwned = 15
    }
    val goldMine1: GoldMines = new GoldMines() {
      numberOwned = 0
    }
    val excavator: Excavators = new Excavators() {
      numberOwned = 2
    }
    val excavator1: Excavators = new Excavators() {
      numberOwned = 0
    }
    val cost1 = 200 * math.pow(1.10, excavator.numberOwned)
    val cost2 = 1000 * math.pow(1.10, goldMine.numberOwned)
    val cost3 = 10 * math.pow(1.05, shovel.numberOwned)

  test("checked") {
    assert(excavator.goldPerClick() == 40.0)
    assert(excavator.goldPerSecond() == 20.0)
    assert(excavator.costOfNextPurchase() == BigDecimal(cost1).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble)
    assert(excavator1.goldPerClick() == 0.0)
    assert(excavator1.goldPerSecond() == 0.0)
    assert(excavator1.costOfNextPurchase() == 200.0)

    assert(shovel.goldPerClick() == 5.0)
    assert(shovel.goldPerSecond() == 0.0)
    assert(shovel.costOfNextPurchase() == BigDecimal(cost3).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble)
    assert(shovel1.goldPerClick() == 0.0)
    assert(shovel1.goldPerSecond() == 0.0)
    assert(shovel1.costOfNextPurchase() == 10.0)

    assert(goldMine.goldPerClick() == 0.0)
    assert(goldMine.goldPerSecond() == 1500.0)
    assert(goldMine.costOfNextPurchase() == BigDecimal(cost2).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble)
    assert(goldMine1.goldPerClick() == 0.0)
    assert(goldMine1.goldPerSecond() == 0.0)
    assert(goldMine1.costOfNextPurchase() == 1000.0)
  }

}
