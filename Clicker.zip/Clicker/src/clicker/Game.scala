package clicker

import play.api.libs.json.{JsValue, Json}
import clicker.equipment._

class Game {

  // Do not change these state variable names, types, or initial values
  //
  // These same names, types, and initial values will be the same in all submissions on AutoLab so you can
  //  use these in your test cases
  var gold: Double = 0.0
  var lastUpdateTime: Long = System.nanoTime()
  var equipment: Map[String, Equipment] = Map("shovel" -> new Shovels, "excavator" -> new Excavators, "mine" -> new GoldMines)
  //

  def goldPerSecond(): Double = {
    val secondGold: Double = equipment("shovel").goldPerSecond() + equipment("excavator").goldPerSecond() + equipment("mine").goldPerSecond()
    secondGold
  }

  def goldPerClick(): Double = {
    val perClick: Double = 1 + equipment("shovel").goldPerClick() + equipment("excavator").goldPerClick() + equipment("mine").goldPerClick()
    perClick
  }


  def toJSON(): String = {
    ""
//    val shovelsOwned = equipment("shovel").numberOwned
//    val minesOwned = equipment("mine").numberOwned
//    val excavatorsOwned = equipment("excavator").numberOwned
//    val form: Map[String, JsValue] = Map(
//      "gold" -> gold,
//      "lastUpdateTime" -> lastUpdateTime,
//      "equipment" -> (
//        "shovel" -> ("numberOwned" -> shovelsOwned, "name" -> "Shovel"),
//        "excavator" -> ("numberOwned" -> excavatorsOwned, "name" -> "Excavator"),
//        "mine" -> ("numberOwned" -> minesOwned, "name" -> "Gold Mine")
//    )
//    )
//    Json.stringify(Json.toJson(form))
  }


  def fromJSON(jsonGameState: String): Unit = {
   // val parsed: JsValue = Json.parse(jsonGameState)
  }


  def clickGold(): Unit = {
    gold += (goldPerClick() + goldPerSecond())
  }

  def buyEquipment(equipmentKey: String): Unit = {
    val purchaseCost = equipment(equipmentKey).costOfNextPurchase()
    if (gold >= equipment(equipmentKey).costOfNextPurchase()) {
      gold -= purchaseCost
      equipment(equipmentKey).numberOwned += 1
    }
  }

  /**
    * takes the current epoch time in nanoseconds
    */
  def update(time: Long): Unit = {
    val total = time - lastUpdateTime
    gold += (total / 10000000000L) * goldPerSecond()
  }


  // Given
  def goldString(): String = {
    f"$gold%1.0f"
  }

  def buttonText(equipmentKey: String): String = {
    val thing: Equipment = this.equipment.getOrElse(equipmentKey, null) // will crash program if key not found
    val cost = thing.costOfNextPurchase()
    val gpc = thing.goldPerClick()
    val gps = thing.goldPerSecond()
    thing.name + f"\n$cost%1.0f gold\n$gpc%1.0f gpc\n$gps%1.0f gps\nowned: " + thing.numberOwned
  }

  //

}
