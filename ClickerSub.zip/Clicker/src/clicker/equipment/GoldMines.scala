package clicker.equipment
import math.pow

class GoldMines extends Equipment{

  this.numberOwned = 0

  override def goldPerSecond(): Double = {
    val perSecond = 100.0 * numberOwned
    perSecond
  }

  override def goldPerClick(): Double = {
    0.0
  }

  override def costOfNextPurchase(): Double = {
    val currentPrice: Double = 1000
    val costAfter: Double = currentPrice*pow(1.10, numberOwned)
    BigDecimal(costAfter).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble
  }


  this.name = "Gold Mine"

}
