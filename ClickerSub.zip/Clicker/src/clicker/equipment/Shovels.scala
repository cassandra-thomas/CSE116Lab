package clicker.equipment

import scala.math.pow

class Shovels extends Equipment {

  this.numberOwned = 0

  override def goldPerSecond(): Double = {
    0.0
  }

  override def goldPerClick(): Double = {
    val perClick = numberOwned * 1
    perClick
  }

  override def costOfNextPurchase(): Double = {
    val currentPrice: Double = 10
    val costAfter: Double = currentPrice*pow(1.05, numberOwned)
    BigDecimal(costAfter).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble
  }


  this.name = "Shovel"


}
