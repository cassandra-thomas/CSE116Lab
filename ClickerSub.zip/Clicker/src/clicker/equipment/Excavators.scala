package clicker.equipment
import math.pow

class Excavators extends Equipment{

  this.numberOwned = 0

  override def goldPerSecond(): Double = {
    val perSecond = numberOwned * 10.0
    perSecond
  }

  override def goldPerClick(): Double = {
    val perClick = 20.0 * numberOwned
    perClick
  }

  override def costOfNextPurchase(): Double = {
    val currentPrice: Double = 200.0
    val costAfter: Double = currentPrice*pow(1.10, numberOwned)
    BigDecimal(costAfter).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble
  }


  this.name = "Excavator"


}
